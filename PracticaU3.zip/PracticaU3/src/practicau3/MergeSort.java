package practicau3;


import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Alejandro
 */
public class MergeSort {
    
public static void main(String[] args) {
    Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese el maximo de valores que desea ordenar:");
        int total = teclado.nextInt();  
        
        int[] arreglo = new int[total];
        for (int i = 0; i < total; i++) {
            System.out.println("Digite el numero " + (i + 1) + " que desea ordenar:");
            arreglo[i] = teclado.nextInt(); 
        }
         
        mergeSort(arreglo, 0, arreglo.length - 1);
        System.out.print("Los numeros en orden son: ");
        for (int i : arreglo) {
            System.out.print(i + " ");
        }
    }
    
    public static void mergeSort(int[] arreglo, int inicio, int fin) {
        if (inicio >= fin) {
            return; // Caso base
        }
        
        int medio = (inicio + fin) / 2;

        // Dividir y ordenar ambas mitades
        mergeSort(arreglo, inicio, medio);
        mergeSort(arreglo, medio + 1, fin);

        // Mezclar las mitades ordenadas
        int n1 = medio - inicio + 1;
        int n2 = fin - medio;

        int[] izquierda = new int[n1];
        int[] derecha = new int[n2];

        for (int i = 0; i < n1; ++i) {
            izquierda[i] = arreglo[inicio + i];
        }
        for (int j = 0; j < n2; ++j) {
            derecha[j] = arreglo[medio + 1 + j];
        }

        int i = 0, j = 0;
        int k = inicio;
        while (i < n1 && j < n2) {
            if (izquierda[i] <= derecha[j]) {
                arreglo[k] = izquierda[i];
                i++;
            } else {
                arreglo[k] = derecha[j];
                j++;
            }
            k++;
        }

        while (i < n1) {
            arreglo[k] = izquierda[i];
            i++;
            k++;
        }

        while (j < n2) {
            arreglo[k] = derecha[j];
            j++;
            k++;
        }
    }

 
}
