/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practicau3;

import java.util.Scanner;

/**
 *
 * @author Brian
 */
public class QuickSort {

    public void ordenarQuickSort(int[] array) {

        array = QuickSort(array);
    }

    public int[] QuickSort(int[] array) {

        return QuickSortA(array, 0, array.length - 1);
    }

    public int[] QuickSortA(int[] valores, int izq, int der) {

        if (izq >= der) {
            return valores;
        }
        
        int i = izq, d = der;

        if (izq != der) {
            int pivote = izq, aux;

            while (izq != der) {
                while (valores[der] >= valores[pivote] && izq < der) {
                    der--;
                }

                while (valores[izq] < valores[pivote] && izq < der) {
                    izq++;
                }

                if (der != izq) {
                    aux = valores[der];
                    valores[der] = valores[izq];
                    valores[izq] = aux;
                }

                if (izq == der) {
                    QuickSortA(valores, i, izq - 1);
                    QuickSortA(valores, izq + 1, d);
                }
            }
        } else {
            return valores;
        }   
        
        return valores;
    }
    
    
    public static void main(String[] args){
        
        Scanner data = new Scanner(System.in);
        
        System.out.print("Ingrese el limite del arreglo = ");
        int limite = data.nextInt();
        int[] arreglo = new int[limite];
        
        System.out.println("Ingrese los valores del arreglo");
        
        for(int i=0; i < limite; i++){
            System.out.print("Valor ["+(i+1)+"]= ");
            arreglo[i] = data.nextInt();
        
        }
        
        QuickSort ordenar = new QuickSort();
        
        ordenar.ordenarQuickSort(arreglo);
        
        System.out.println("Valores Ordenados: ");
        for(int datos: arreglo){
            System.out.print(datos);
            System.out.print("-");
        }
        System.out.println("");
    }
    

}
