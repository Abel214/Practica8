/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practicau3;

import java.util.Scanner;

/**
 *
 * @author Alejandro
 */
public class TablaMultiplicar {

    Scanner valor = new Scanner(System.in);

    public static void main(String args[]) {
        TablaMultiplicar tm = new TablaMultiplicar();

        System.out.print("Ingrese el numero para generar la tabla de multiplicacion = ");
        int num = tm.valor.nextInt();
        
        System.out.print("Ingre el limite de la tabla = ");
        int limite = tm.valor.nextInt();
        
        tm.tabla(num, limite);
    }

    public void tabla(int num, int limite) {

        if (num == 0 && limite == 0) {
            System.out.println("No es posible generar la tabla de multiplicación");
        } else {
            for (int i = 0; i <= limite; i++) {
                int mtp = num * i;
                System.out.println("" + num + " x " + i + " = " + mtp);

            }
        }

    }

}
