/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practicau3;

import java.util.Scanner;

/**
 *
 * @author Brian
 */
public class SumaArreglo {

    Scanner dato = new Scanner(System.in);

    public static void main(String arg[]) {

        SumaArreglo suma = new SumaArreglo();
        System.out.print("Ingrese el tamaño del arreglo = ");
        int num = suma.dato.nextInt();

        int aux = suma.sumaArreglo(num);

        if (aux != 0) {
            System.out.println("La sumatoria de los elementos del arreglo ingresado es: " + aux);

        }

    }

    public int sumaArreglo(int tamanio) {

        int arreglo[] = new int[tamanio];
        int aux = 0;

        if (arreglo.length == 0) {
            System.out.println("No se puede realizar la sumatoria ");
        } else {
            System.out.println("Ingrese los valores del arreglo: ");

            for (int i = 0; i < tamanio; i++) {
                System.out.print("Valor [" + (i + 1) + "] = ");
                arreglo[i] = dato.nextInt();
            }

            for (int i = 0; i < tamanio; i++) {
                aux = arreglo[i] + aux;
            }
        }
        return aux;
    }

}
